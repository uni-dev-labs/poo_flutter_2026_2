import 'package:flutter/material.dart';

class PostInstagram extends StatefulWidget {
  final String nombreUsuario;
  final String inicialUsuario;
  final List<String> imagenesPost;
  final String descripcion;
  final String likes;
  final String comentarios;

  const PostInstagram({
    super.key,
    required this.nombreUsuario,
    required this.inicialUsuario,
    required this.imagenesPost,
    required this.descripcion,
    required this.likes,
    required this.comentarios,
  });

  @override
  State<PostInstagram> createState() => _PostInstagramState();
}

class _PostInstagramState extends State<PostInstagram> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 450),
        margin: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(16.0),
          border: Border.all(color: Colors.white10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
           
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 10.0),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(2),
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [Colors.purple, Colors.red, Colors.orange],
                      ),
                    ),
                    child: CircleAvatar(
                      radius: 16,
                      backgroundColor: Colors.blueAccent,
                      child: Text(
                        widget.inicialUsuario,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    widget.nombreUsuario,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                  const Spacer(),
                  const Icon(Icons.more_vert, color: Colors.white, size: 20),
                ],
              ),
            ),

            
            SizedBox(
              height: 350,
              child: PageView.builder(
                controller: _pageController,
                itemCount: widget.imagenesPost.length,
                onPageChanged: (index) {
                  setState(() {
                    _currentPage = index;
                  });
                },
                itemBuilder: (context, index) {
                  return Image.network(
                    widget.imagenesPost[index],
                    fit: BoxFit.cover,
                    width: double.infinity,
                  );
                },
              ),
            ),

           
            if (widget.imagenesPost.length > 1)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    widget.imagenesPost.length,
                    (index) => Container(
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _currentPage == index ? Colors.blue : Colors.grey[700],
                      ),
                    ),
                  ),
                ),
              ),

        
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
              child: Row(
                children: [
                  const Icon(Icons.favorite_border, color: Colors.white, size: 26),
                  const SizedBox(width: 6),
                  Text(widget.likes, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(width: 16),
                  const Icon(Icons.chat_bubble_outline, color: Colors.white, size: 24),
                  const SizedBox(width: 6),
                  Text(widget.comentarios, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(width: 16),
                  const Icon(Icons.send_outlined, color: Colors.white, size: 24),
                  const SizedBox(width: 6),
                  const Text('17', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                  const Spacer(),
                  const Icon(Icons.bookmark_border, color: Colors.white, size: 26),
                ],
              ),
            ),

          
            Padding(
              padding: const EdgeInsets.fromLTRB(12.0, 0, 12.0, 14.0),
              child: Text.rich(
                TextSpan(
                  children: [
                    TextSpan(
                      text: '${widget.nombreUsuario} ',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                    TextSpan(
                      text: widget.descripcion,
                      style: const TextStyle(color: Colors.white, fontSize: 13),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}