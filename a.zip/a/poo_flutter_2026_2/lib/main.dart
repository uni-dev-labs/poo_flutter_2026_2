import 'package:flutter/material.dart';
import 'widget/hstoria_usuario.dart';
import 'widget/post_instagram.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
      ),
      home: Scaffold(
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 10),
                
                
                Center(
                  child: SizedBox(
                    height: 105,
                    child: ListView(
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      children: const [
                        HistoriaUsuario(nombre: 'andres', inicial: 'A'),
                        HistoriaUsuario(nombre: 'maria', inicial: 'M'),
                        HistoriaUsuario(nombre: 'juan', inicial: 'J'),
                        HistoriaUsuario(nombre: 'pedro', inicial: 'P'),
                        HistoriaUsuario(nombre: 'cely', inicial: 'C'),
                      ],
                    ),
                  ),
                ),
                
                const Divider(color: Colors.white12, height: 1),
                const SizedBox(height: 10),

                const PostInstagram(
                  nombreUsuario: 'CELY',
                  inicialUsuario: 'C',
                  imagenesPost: [
                    'https://upload.wikimedia.org/wikipedia/commons/d/d3/Albert_Einstein_Head.jpg',
                    'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800',
                  ],
                  descripcion: 'aaaaaaaaaaaaaaaaaaaaa',
                  likes: '120',
                  comentarios: '1',
                ),
                
                const SizedBox(height: 15),

               
                const PostInstagram(
                  nombreUsuario: 'maria',
                  inicialUsuario: 'M',
                  imagenesPost: [
                    'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=800',
                    'https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?w=800',
                  ],
                  descripcion: 'Disfrutando del día con los perritos ',
                  likes: '345',
                  comentarios: '12',
                ),

                const SizedBox(height: 15),

                const PostInstagram(
                  nombreUsuario: 'andres',
                  inicialUsuario: 'A',
                  imagenesPost: [
                    'https://images.unsplash.com/photo-1517849845537-4d257902454a?w=800',
                    'https://images.unsplash.com/photo-1546238232-20216dec9f72?w=800',
                  ],
                  descripcion: 'Un gran día de aventuras ',
                  likes: '89',
                  comentarios: '4',
                ),

                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}